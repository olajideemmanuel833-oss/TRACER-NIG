/**
 * TRACER-NG — SOS Routes
 * Handles emergency panic signals from victim devices.
 * Simultaneously alerts NPF, DSS, DHQ Army and family contacts.
 * Never blocks — always responds, even under load.
 */

const express = require('express');
const router  = express.Router();
const crypto  = require('crypto');
const { getDB } = require('../config/database');
const { authenticateDevice } = require('../middleware/auth');
const { broadcastToAgencies, notifyFamily } = require('../services/agencyDispatch');
const { sendSMSAlert } = require('../services/smsService');
const { logger } = require('../utils/logger');

// ─── POST /api/sos ───────────────────────────────────────────────────────────
// Victim device triggers SOS — this is the most critical endpoint
router.post('/', authenticateDevice, async (req, res) => {

  // IMMEDIATELY acknowledge to the device — never make victim wait
  res.status(200).json({
    status:  'received',
    message: 'SOS received. Emergency services alerted.',
    sosId:   crypto.randomUUID(),
  });

  // Process SOS asynchronously AFTER responding
  setImmediate(async () => {
    try {
      const db = getDB();
      const victimId   = req.device.victimId;
      const deviceIMEI = req.headers['x-device-imei'];

      const {
        lat, lon, accuracy,
        triggerMethod,  // 'SHAKE' | 'GESTURE' | 'POWER_BUTTON' | 'MANUAL'
        message,        // optional voice/text message from victim
        timestamp,
      } = req.body;

      logger.warn(`[SOS] *** EMERGENCY *** Victim: ${victimId} | Location: ${lat},${lon} | Method: ${triggerMethod}`);

      // 1. Get full case details
      const caseData = await db.collection('cases').findOne({ victimId });
      if (!caseData) {
        logger.error(`[SOS] No case found for victim ${victimId}`);
        return;
      }

      // 2. Record SOS event in database
      const sosEvent = {
        sosId:          crypto.randomUUID(),
        victimId,
        deviceIMEI,
        caseName:       caseData.victimName,
        lat:            parseFloat(lat),
        lon:            parseFloat(lon),
        accuracy:       parseFloat(accuracy) || null,
        triggerMethod,
        message:        message || null,
        triggeredAt:    new Date(),
        deviceTimestamp: timestamp ? new Date(timestamp) : new Date(),
        agenciesAlerted: [],
        status:         'ACTIVE',
      };

      await db.collection('sos_events').insertOne(sosEvent);

      // 3. Update case status to SOS
      await db.collection('cases').updateOne(
        { victimId },
        {
          $set: {
            status:       'SOS_ACTIVE',
            lastSOSAt:    new Date(),
            lastSOSLat:   sosEvent.lat,
            lastSOSLon:   sosEvent.lon,
            deviceStatus: 'SOS',
          },
          $push: { sosHistory: sosEvent.sosId },
        }
      );

      // 4. Build emergency payload for all agencies
      const emergencyPayload = {
        type:        'SOS',
        priority:    'CRITICAL',
        victimId,
        victimName:  caseData.victimName,
        victimAge:   caseData.victimAge,
        caseId:      caseData.caseId,
        lat:         sosEvent.lat,
        lon:         sosEvent.lon,
        accuracy:    sosEvent.accuracy,
        googleMapsUrl: `https://maps.google.com/?q=${sosEvent.lat},${sosEvent.lon}`,
        triggeredAt: sosEvent.triggeredAt.toISOString(),
        message:     `EMERGENCY SOS from ${caseData.victimName}. Immediate response required.`,
        deviceIMEI,
        triggerMethod,
      };

      // 5. Dispatch to ALL agencies simultaneously (parallel, not sequential)
      const [npfResult, dssResult, dhqResult] = await Promise.allSettled([
        broadcastToAgencies({ ...emergencyPayload, agency: 'NPF' }),  // Nigerian Police Force
        broadcastToAgencies({ ...emergencyPayload, agency: 'DSS' }),  // State Security Service
        broadcastToAgencies({ ...emergencyPayload, agency: 'DHQ' }),  // Defence HQ Army
      ]);

      // 6. SMS fallback — if webhook fails, send SMS to duty officers
      const agencyNumbers = [
        process.env.NPF_DUTY_OFFICER_PHONE,
        process.env.DSS_DUTY_OFFICER_PHONE,
        process.env.DHQ_DUTY_OFFICER_PHONE,
      ].filter(Boolean);

      await Promise.allSettled(
        agencyNumbers.map(phone =>
          sendSMSAlert(phone, [
            `TRACER-NG EMERGENCY SOS`,
            `Victim: ${caseData.victimName}`,
            `Case: ${caseData.caseId}`,
            `Location: ${sosEvent.lat}, ${sosEvent.lon}`,
            `Maps: https://maps.google.com/?q=${sosEvent.lat},${sosEvent.lon}`,
            `Time: ${sosEvent.triggeredAt.toLocaleString('en-NG')}`,
          ].join('\n'))
        )
      );

      // 7. Notify family contact
      if (caseData.familyPhone) {
        await notifyFamily(caseData.familyPhone, {
          victimName: caseData.victimName,
          lat: sosEvent.lat,
          lon: sosEvent.lon,
        });
      }

      // 8. Log agency dispatch results
      const alertedAgencies = [];
      if (npfResult.status === 'fulfilled') alertedAgencies.push('NPF');
      if (dssResult.status === 'fulfilled') alertedAgencies.push('DSS');
      if (dhqResult.status === 'fulfilled') alertedAgencies.push('DHQ');

      await db.collection('sos_events').updateOne(
        { sosId: sosEvent.sosId },
        { $set: { agenciesAlerted: alertedAgencies } }
      );

      logger.warn(`[SOS DISPATCHED] Victim ${victimId} | Agencies: ${alertedAgencies.join(', ')}`);

    } catch (err) {
      logger.error('[SOS PROCESSING ERROR]', err);
    }
  });
});

// ─── POST /api/sos/:sosId/resolve ─────────────────────────────────────────
// Law enforcement marks an SOS as resolved (victim recovered)
router.post('/:sosId/resolve', async (req, res) => {
  try {
    const db = getDB();
    const { sosId } = req.params;
    const { resolvedBy, resolution, notes } = req.body;

    const result = await db.collection('sos_events').updateOne(
      { sosId },
      {
        $set: {
          status:     'RESOLVED',
          resolvedAt: new Date(),
          resolvedBy,
          resolution, // 'VICTIM_RECOVERED' | 'FALSE_ALARM' | 'ONGOING'
          notes,
        }
      }
    );

    if (result.matchedCount === 0) {
      return res.status(404).json({ error: 'SOS event not found' });
    }

    logger.info(`[SOS RESOLVED] ${sosId} by ${resolvedBy}: ${resolution}`);
    res.json({ status: 'resolved', sosId });

  } catch (err) {
    logger.error('[SOS RESOLVE ERROR]', err);
    res.status(500).json({ error: 'Failed to resolve SOS' });
  }
});

// ─── GET /api/sos/active ──────────────────────────────────────────────────
// Dashboard: get all currently active SOS alerts
router.get('/active', async (req, res) => {
  try {
    const db = getDB();
    const active = await db.collection('sos_events')
      .find({ status: 'ACTIVE' })
      .sort({ triggeredAt: -1 })
      .project({ _id: 0 })
      .toArray();

    res.json({ count: active.length, events: active });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch active SOS events' });
  }
});

module.exports = router;
