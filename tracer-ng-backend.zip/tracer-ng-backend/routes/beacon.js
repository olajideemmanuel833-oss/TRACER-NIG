/**
 * TRACER-NG — Beacon Routes
 * Receives GPS pings from victim devices every 60 seconds.
 * Handles: live beacons, offline cache sync, last-known storage,
 * low-battery final beacons, and cell-tower fallback data.
 */

const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const { getDB } = require('../config/database');
const { authenticateDevice } = require('../middleware/auth');
const { decryptPayload, validateCoords } = require('../utils/crypto');
const { logger } = require('../utils/logger');
const { broadcastToAgencies } = require('../services/agencyDispatch');

// ─── POST /api/beacon ────────────────────────────────────────────────────────
// Primary endpoint: mobile app sends GPS location here every 60 seconds
router.post('/', authenticateDevice, async (req, res) => {
  try {
    const db = getDB();
    const deviceIMEI = req.headers['x-device-imei'];
    const victimId   = req.device.victimId;

    // 1. Decrypt the incoming payload (AES-256-GCM)
    const raw = req.body.encrypted
      ? decryptPayload(req.body.data, process.env.BEACON_ENCRYPTION_KEY)
      : req.body;

    const {
      lat, lon, accuracy, altitude,
      timestamp, battery, isMoving,
      networkType,   // 'GPS' | 'CELL' | 'WIFI' | 'OFFLINE'
      type,          // 'HEARTBEAT' | 'FINAL_BEACON' | 'SOS' | 'CACHE_SYNC'
      cellTowers,    // fallback cell tower data
      wifiSSIDs,     // fallback WiFi data
    } = raw;

    // 2. Validate coordinates are within Nigeria bounding box
    // Nigeria: lat 4.27–13.89, lon 2.67–14.68
    if (!validateCoords(lat, lon)) {
      return res.status(422).json({ error: 'Coordinates out of valid range' });
    }

    // 3. Build beacon record
    const beacon = {
      victimId,
      deviceIMEI,
      lat:        parseFloat(lat),
      lon:        parseFloat(lon),
      accuracy:   parseFloat(accuracy) || null,
      altitude:   parseFloat(altitude) || null,
      battery:    battery ?? null,
      isMoving:   isMoving ?? null,
      networkType: networkType || 'GPS',
      type:       type || 'HEARTBEAT',
      receivedAt: new Date(),
      deviceTimestamp: timestamp ? new Date(timestamp) : new Date(),
      cellTowers: cellTowers || null,
      wifiSSIDs:  wifiSSIDs  || null,
      beaconId:   crypto.randomUUID(),
    };

    // 4. Store beacon in database
    await db.collection('beacons').insertOne(beacon);

    // 5. Update case's "last known location"
    await db.collection('cases').updateOne(
      { victimId },
      {
        $set: {
          lastKnownLat:    beacon.lat,
          lastKnownLon:    beacon.lon,
          lastBeaconAt:    beacon.receivedAt,
          lastBattery:     beacon.battery,
          lastNetworkType: beacon.networkType,
          deviceStatus:    battery !== undefined && battery < 5
            ? 'CRITICAL_BATTERY'
            : 'ACTIVE',
        },
        $inc: { totalBeacons: 1 },
      }
    );

    // 6. CRITICAL BATTERY ALERT — battery below 5%, final beacon incoming
    if (battery !== undefined && battery < 5) {
      logger.warn(`[CRITICAL] Victim ${victimId} battery at ${battery}% — final beacon imminent`);
      await broadcastToAgencies({
        type:    'CRITICAL_BATTERY',
        victimId,
        lat:     beacon.lat,
        lon:     beacon.lon,
        battery,
        message: `CRITICAL: Device battery at ${battery}%. This may be the last known location.`,
      });
    }

    // 7. FINAL BEACON — device is shutting down
    if (type === 'FINAL_BEACON') {
      logger.warn(`[FINAL BEACON] Victim ${victimId} device shutting down at ${lat}, ${lon}`);
      await db.collection('cases').updateOne(
        { victimId },
        {
          $set: {
            deviceStatus:    'OFFLINE',
            finalBeaconAt:   new Date(),
            finalBeaconLat:  beacon.lat,
            finalBeaconLon:  beacon.lon,
          }
        }
      );
      await broadcastToAgencies({
        type:    'FINAL_BEACON',
        victimId,
        lat:     beacon.lat,
        lon:     beacon.lon,
        message: `ALERT: Device powered off. Last known location recorded.`,
      });
    }

    logger.info(`[BEACON] Victim ${victimId} | ${lat},${lon} | ${networkType} | Battery:${battery}%`);

    res.status(200).json({
      status:   'received',
      beaconId: beacon.beaconId,
      nextPing: 60, // tell device to ping again in 60 seconds
    });

  } catch (err) {
    logger.error('[BEACON ERROR]', err);
    res.status(500).json({ error: 'Beacon processing failed' });
  }
});

// ─── POST /api/beacon/cache-sync ─────────────────────────────────────────────
// Device sends stored offline beacons when internet returns
router.post('/cache-sync', authenticateDevice, async (req, res) => {
  try {
    const db = getDB();
    const victimId = req.device.victimId;
    const { beacons } = req.body; // Array of cached beacons

    if (!Array.isArray(beacons) || beacons.length === 0) {
      return res.status(400).json({ error: 'No beacons to sync' });
    }

    // Validate & insert all cached beacons
    const validBeacons = beacons
      .filter(b => validateCoords(b.lat, b.lon))
      .map(b => ({
        ...b,
        victimId,
        deviceIMEI: req.headers['x-device-imei'],
        receivedAt: new Date(),
        type: 'CACHE_SYNC',
        beaconId: crypto.randomUUID(),
      }));

    if (validBeacons.length > 0) {
      await db.collection('beacons').insertMany(validBeacons);
      logger.info(`[CACHE SYNC] Victim ${victimId} synced ${validBeacons.length} offline beacons`);
    }

    // Update last known location to most recent synced beacon
    const mostRecent = validBeacons.sort(
      (a, b) => new Date(b.deviceTimestamp) - new Date(a.deviceTimestamp)
    )[0];

    if (mostRecent) {
      await db.collection('cases').updateOne(
        { victimId },
        { $set: {
          lastKnownLat: mostRecent.lat,
          lastKnownLon: mostRecent.lon,
          lastBeaconAt: new Date(mostRecent.deviceTimestamp),
          deviceStatus: 'RECONNECTED',
        }}
      );
    }

    res.json({ status: 'synced', count: validBeacons.length });

  } catch (err) {
    logger.error('[CACHE SYNC ERROR]', err);
    res.status(500).json({ error: 'Cache sync failed' });
  }
});

// ─── GET /api/beacon/:victimId/history ──────────────────────────────────────
// Law enforcement: get full location history for a case
router.get('/:victimId/history', async (req, res) => {
  try {
    const db = getDB();
    const { victimId } = req.params;
    const { limit = 100, from, to } = req.query;

    const query = { victimId };
    if (from || to) {
      query.receivedAt = {};
      if (from) query.receivedAt.$gte = new Date(from);
      if (to)   query.receivedAt.$lte = new Date(to);
    }

    const beacons = await db.collection('beacons')
      .find(query)
      .sort({ receivedAt: -1 })
      .limit(parseInt(limit))
      .project({ _id: 0, cellTowers: 0, wifiSSIDs: 0 }) // strip sensitive fields
      .toArray();

    res.json({
      victimId,
      count: beacons.length,
      beacons,
    });

  } catch (err) {
    logger.error('[HISTORY ERROR]', err);
    res.status(500).json({ error: 'Failed to fetch history' });
  }
});

// ─── GET /api/beacon/:victimId/last-known ───────────────────────────────────
// Get the single most recent location (even if device is offline/destroyed)
router.get('/:victimId/last-known', async (req, res) => {
  try {
    const db = getDB();
    const { victimId } = req.params;

    const last = await db.collection('beacons')
      .findOne(
        { victimId },
        { sort: { receivedAt: -1 }, projection: { _id: 0 } }
      );

    if (!last) {
      return res.status(404).json({ error: 'No beacons found for this victim' });
    }

    const caseInfo = await db.collection('cases').findOne({ victimId });

    res.json({
      victimId,
      lastKnown: {
        lat:          last.lat,
        lon:          last.lon,
        accuracy:     last.accuracy,
        timestamp:    last.receivedAt,
        battery:      last.battery,
        networkType:  last.networkType,
        type:         last.type,
        minutesAgo:   Math.floor((Date.now() - new Date(last.receivedAt)) / 60000),
      },
      deviceStatus: caseInfo?.deviceStatus || 'UNKNOWN',
    });

  } catch (err) {
    logger.error('[LAST KNOWN ERROR]', err);
    res.status(500).json({ error: 'Failed to fetch last known location' });
  }
});

module.exports = router;
