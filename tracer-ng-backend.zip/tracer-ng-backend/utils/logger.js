/**
 * TRACER-NG — Logger
 * Winston-based structured logger
 */

const { createLogger, format, transports } = require('winston');
const path = require('path');

const logger = createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: format.combine(
    format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    format.errors({ stack: true }),
    format.json()
  ),
  transports: [
    // Console output (coloured in dev)
    new transports.Console({
      format: process.env.NODE_ENV === 'development'
        ? format.combine(format.colorize(), format.simple())
        : format.json(),
    }),
    // File: all logs
    new transports.File({
      filename: path.join(__dirname, '../logs/tracer-ng.log'),
      maxsize:  10 * 1024 * 1024, // 10MB
      maxFiles: 5,
    }),
    // File: errors only
    new transports.File({
      filename: path.join(__dirname, '../logs/errors.log'),
      level:    'error',
    }),
  ],
});

module.exports = { logger };
