/**
 * TRACER-NG — Crypto Utilities
 * AES-256-GCM encryption/decryption for GPS beacon payloads
 */

// utils/crypto.js
const crypto = require('crypto');

const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH = 16;
const TAG_LENGTH = 16;

function decryptPayload(encryptedData, key) {
  const buffer    = Buffer.from(encryptedData, 'base64');
  const iv        = buffer.slice(0, IV_LENGTH);
  const tag       = buffer.slice(IV_LENGTH, IV_LENGTH + TAG_LENGTH);
  const encrypted = buffer.slice(IV_LENGTH + TAG_LENGTH);
  const keyBuffer = Buffer.from(key, 'hex'); // 32-byte key as hex

  const decipher = crypto.createDecipheriv(ALGORITHM, keyBuffer, iv);
  decipher.setAuthTag(tag);

  const decrypted = Buffer.concat([decipher.update(encrypted), decipher.final()]);
  return JSON.parse(decrypted.toString('utf8'));
}

function encryptPayload(data, key) {
  const iv        = crypto.randomBytes(IV_LENGTH);
  const keyBuffer = Buffer.from(key, 'hex');
  const cipher    = crypto.createCipheriv(ALGORITHM, keyBuffer, iv);

  const encrypted = Buffer.concat([
    cipher.update(JSON.stringify(data), 'utf8'),
    cipher.final(),
  ]);
  const tag = cipher.getAuthTag();

  return Buffer.concat([iv, tag, encrypted]).toString('base64');
}

// Validate coordinates within Nigeria bounding box
function validateCoords(lat, lon) {
  const LAT_MIN = 4.27,  LAT_MAX = 13.89;
  const LON_MIN = 2.67,  LON_MAX = 14.68;
  return (
    lat >= LAT_MIN && lat <= LAT_MAX &&
    lon >= LON_MIN && lon <= LON_MAX
  );
}

module.exports = { decryptPayload, encryptPayload, validateCoords };

---

/**
 * TRACER-NG — Auth Middleware
 * Authenticates device tokens from mobile app
 */

// middleware/auth.js
const jwt = require('jsonwebtoken');
const { logger } = require('../utils/logger');

function authenticateDevice(req, res, next) {
  const token = req.headers['authorization']?.replace('Bearer ', '');
  if (!token) {
    return res.status(401).json({ error: 'No authorization token provided' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.device = decoded; // { victimId, deviceIMEI, caseId }
    next();
  } catch (err) {
    logger.warn(`[AUTH] Invalid token: ${err.message}`);
    return res.status(403).json({ error: 'Invalid or expired device token' });
  }
}

function authenticateOfficer(req, res, next) {
  const token = req.headers['authorization']?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'No token' });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    if (!['NPF', 'DSS', 'DHQ', 'ADMIN'].includes(decoded.role)) {
      return res.status(403).json({ error: 'Insufficient permissions' });
    }
    req.officer = decoded;
    next();
  } catch (err) {
    return res.status(403).json({ error: 'Invalid token' });
  }
}

module.exports = { authenticateDevice, authenticateOfficer };
