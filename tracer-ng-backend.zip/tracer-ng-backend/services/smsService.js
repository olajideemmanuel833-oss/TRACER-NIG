/**
 * TRACER-NG — SMS Alert Service
 * Uses Africa's Talking API (best coverage in Nigeria)
 * Fallback: Termii (Nigerian SMS provider)
 *
 * Africa's Talking supports: MTN, Airtel, Glo, 9mobile
 */

const axios = require('axios');
const { logger } = require('../utils/logger');

// Africa's Talking credentials (primary)
const AT_API_KEY   = process.env.AFRICASTALKING_API_KEY;
const AT_USERNAME  = process.env.AFRICASTALKING_USERNAME;
const AT_SENDER_ID = process.env.SMS_SENDER_ID || 'TRACERNG';

// Termii credentials (fallback - Nigerian provider)
const TERMII_KEY    = process.env.TERMII_API_KEY;
const TERMII_SENDER = process.env.TERMII_SENDER_ID || 'TRACERNG';

/**
 * sendSMSAlert()
 * Send SMS to a Nigerian phone number
 * Automatically tries Africa's Talking, then Termii
 *
 * @param {string} phone - Phone number e.g. "+2348012345678"
 * @param {string} message - SMS text
 */
async function sendSMSAlert(phone, message) {
  // Normalize Nigerian phone number to international format
  const normalized = normalizeNigerianPhone(phone);
  if (!normalized) {
    logger.warn(`[SMS] Invalid phone number: ${phone}`);
    return { success: false, reason: 'Invalid phone number' };
  }

  // Try Africa's Talking first
  if (AT_API_KEY && AT_USERNAME) {
    try {
      const result = await sendViaAfricasTalking(normalized, message);
      logger.info(`[SMS] ✓ Sent via Africa's Talking to ${maskPhone(normalized)}`);
      return result;
    } catch (err) {
      logger.warn(`[SMS] Africa's Talking failed: ${err.message} — trying Termii`);
    }
  }

  // Fallback: Termii
  if (TERMII_KEY) {
    try {
      const result = await sendViaTermii(normalized, message);
      logger.info(`[SMS] ✓ Sent via Termii to ${maskPhone(normalized)}`);
      return result;
    } catch (err) {
      logger.error(`[SMS] Termii also failed: ${err.message}`);
    }
  }

  // Last resort: log for manual sending
  logger.error(`[SMS FAILED] Could not send to ${maskPhone(normalized)}: ${message}`);
  return { success: false, reason: 'All SMS providers failed' };
}

/**
 * sendViaAfricasTalking()
 * Africa's Talking has the best Nigeria coverage
 */
async function sendViaAfricasTalking(phone, message) {
  const params = new URLSearchParams({
    username: AT_USERNAME,
    to:       phone,
    message,
    from:     AT_SENDER_ID,
  });

  const response = await axios.post(
    'https://api.africastalking.com/version1/messaging',
    params.toString(),
    {
      headers: {
        'Accept':       'application/json',
        'Content-Type': 'application/x-www-form-urlencoded',
        'apiKey':       AT_API_KEY,
      },
      timeout: 10000,
    }
  );

  const { SMSMessageData } = response.data;
  if (SMSMessageData?.Recipients?.[0]?.status === 'Success') {
    return { success: true, provider: 'africastalking', messageId: SMSMessageData.Recipients[0].messageId };
  }

  throw new Error(`Africa's Talking: ${SMSMessageData?.Message || 'Unknown error'}`);
}

/**
 * sendViaTermii()
 * Termii is a Nigerian SMS provider — good local delivery
 */
async function sendViaTermii(phone, message) {
  const response = await axios.post(
    'https://api.ng.termii.com/api/sms/send',
    {
      to:       phone,
      from:     TERMII_SENDER,
      sms:      message,
      type:     'plain',
      api_key:  TERMII_KEY,
      channel:  'generic',
    },
    {
      headers: { 'Content-Type': 'application/json' },
      timeout: 10000,
    }
  );

  if (response.data?.code === 'ok') {
    return { success: true, provider: 'termii', messageId: response.data.message_id };
  }

  throw new Error(`Termii: ${response.data?.message || 'Unknown error'}`);
}

/**
 * sendBulkSMS()
 * Send the same alert to multiple numbers at once
 */
async function sendBulkSMS(phones, message) {
  const results = await Promise.allSettled(
    phones.map(phone => sendSMSAlert(phone, message))
  );

  const summary = results.reduce((acc, r, i) => {
    acc[phones[i]] = r.status === 'fulfilled' ? r.value : { success: false };
    return acc;
  }, {});

  const successful = results.filter(r => r.status === 'fulfilled' && r.value?.success).length;
  logger.info(`[BULK SMS] ${successful}/${phones.length} sent successfully`);
  return summary;
}

/**
 * normalizeNigerianPhone()
 * Converts any format to +234XXXXXXXXXX
 * Handles: 08012345678, 8012345678, +2348012345678, 2348012345678
 */
function normalizeNigerianPhone(phone) {
  const digits = phone.replace(/\D/g, '');

  if (digits.startsWith('234') && digits.length === 13) return `+${digits}`;
  if (digits.startsWith('0') && digits.length === 11)   return `+234${digits.slice(1)}`;
  if (digits.length === 10)                              return `+234${digits}`;

  return null; // Invalid
}

/**
 * maskPhone()
 * Mask phone for logging: +234801****5678
 */
function maskPhone(phone) {
  return phone.slice(0, 7) + '****' + phone.slice(-4);
}

module.exports = { sendSMSAlert, sendBulkSMS };
