/**
 * TRACER-NG — Agency Dispatch Service
 * Sends real-time alerts to:
 *   - Nigerian Police Force (NPF)
 *   - Department of State Services (DSS)
 *   - Defence Headquarters / Army Quick Response (DHQ)
 *   - Family contacts
 *
 * Uses webhooks (primary) + SMS fallback (secondary)
 */

const axios = require('axios');
const { logger } = require('../utils/logger');
const { getDB } = require('../config/database');

// Agency webhook configurations (set in .env)
const AGENCIES = {
  NPF: {
    name:       'Nigerian Police Force',
    webhookUrl:  process.env.NPF_WEBHOOK_URL,
    apiKey:      process.env.NPF_API_KEY,
    smsNumber:   process.env.NPF_DUTY_OFFICER_PHONE,
    email:       process.env.NPF_ALERT_EMAIL,
  },
  DSS: {
    name:       'Dept. of State Services',
    webhookUrl:  process.env.DSS_WEBHOOK_URL,
    apiKey:      process.env.DSS_API_KEY,
    smsNumber:   process.env.DSS_DUTY_OFFICER_PHONE,
    email:       process.env.DSS_ALERT_EMAIL,
  },
  DHQ: {
    name:       'Defence HQ / Army QRF',
    webhookUrl:  process.env.DHQ_WEBHOOK_URL,
    apiKey:      process.env.DHQ_API_KEY,
    smsNumber:   process.env.DHQ_DUTY_OFFICER_PHONE,
    email:       process.env.DHQ_ALERT_EMAIL,
  },
};

/**
 * broadcastToAgencies()
 * Sends an alert payload to a specific agency via webhook.
 * Falls back to SMS if webhook fails.
 */
async function broadcastToAgencies(payload) {
  const { agency, ...alertData } = payload;
  const config = AGENCIES[agency];

  if (!config) {
    logger.warn(`[DISPATCH] Unknown agency: ${agency}`);
    return { success: false, reason: 'Unknown agency' };
  }

  logger.info(`[DISPATCH] Sending ${payload.type} alert to ${config.name}`);

  // Build standardized alert envelope
  const alertEnvelope = {
    system:     'TRACER-NG',
    version:    '1.0',
    alertId:    require('crypto').randomUUID(),
    agency,
    priority:   payload.priority || 'HIGH',
    type:       payload.type,
    timestamp:  new Date().toISOString(),
    victim: {
      id:        alertData.victimId,
      name:      alertData.victimName,
      caseId:    alertData.caseId,
    },
    location: {
      lat:          alertData.lat,
      lon:          alertData.lon,
      accuracy:     alertData.accuracy,
      googleMapsUrl: alertData.googleMapsUrl ||
        `https://maps.google.com/?q=${alertData.lat},${alertData.lon}`,
      timestamp:    alertData.triggeredAt || new Date().toISOString(),
    },
    message: alertData.message,
    metadata: {
      deviceIMEI:    alertData.deviceIMEI,
      triggerMethod: alertData.triggerMethod,
    },
  };

  // Try webhook first
  if (config.webhookUrl) {
    try {
      const response = await axios.post(config.webhookUrl, alertEnvelope, {
        headers: {
          'Content-Type':  'application/json',
          'X-API-Key':      config.apiKey,
          'X-System':       'TRACER-NG',
          'X-Alert-Type':   payload.type,
        },
        timeout: 8000, // 8 second timeout
      });

      logger.info(`[DISPATCH] ✓ ${config.name} webhook ACK: ${response.status}`);
      await logDispatch(alertEnvelope, agency, 'WEBHOOK', 'SUCCESS');
      return { success: true, method: 'webhook', agency };

    } catch (webhookErr) {
      logger.warn(`[DISPATCH] ${config.name} webhook failed: ${webhookErr.message} — trying SMS fallback`);
    }
  }

  // SMS fallback
  if (config.smsNumber) {
    try {
      const { sendSMSAlert } = require('./smsService');
      const smsText = formatSMSAlert(alertEnvelope);
      await sendSMSAlert(config.smsNumber, smsText);
      logger.info(`[DISPATCH] ✓ ${config.name} SMS fallback sent`);
      await logDispatch(alertEnvelope, agency, 'SMS', 'SUCCESS');
      return { success: true, method: 'sms', agency };

    } catch (smsErr) {
      logger.error(`[DISPATCH] ${config.name} SMS also failed: ${smsErr.message}`);
    }
  }

  await logDispatch(alertEnvelope, agency, 'ALL', 'FAILED');
  return { success: false, agency, reason: 'All dispatch methods failed' };
}

/**
 * notifyFamily()
 * Send SMS to victim's registered family contact
 */
async function notifyFamily(phone, data) {
  try {
    const { sendSMSAlert } = require('./smsService');
    const msg = [
      `TRACER-NG EMERGENCY ALERT`,
      `Your family member ${data.victimName} has triggered an emergency SOS.`,
      `Authorities have been notified.`,
      `Last known location: https://maps.google.com/?q=${data.lat},${data.lon}`,
      `Please contact Nigerian Police: 199`,
    ].join('\n');

    await sendSMSAlert(phone, msg);
    logger.info(`[FAMILY ALERT] Notified family contact for ${data.victimName}`);
  } catch (err) {
    logger.error('[FAMILY ALERT ERROR]', err);
  }
}

/**
 * formatSMSAlert()
 * Compact SMS message for agency duty officers (160 char limit)
 */
function formatSMSAlert(envelope) {
  return [
    `🚨 TRACER-NG ${envelope.type}`,
    `Victim: ${envelope.victim.name} [${envelope.victim.caseId}]`,
    `GPS: ${envelope.location.lat.toFixed(4)},${envelope.location.lon.toFixed(4)}`,
    `Map: ${envelope.location.googleMapsUrl}`,
    `Time: ${new Date(envelope.timestamp).toLocaleString('en-NG')}`,
  ].join(' | ');
}

/**
 * logDispatch()
 * Record every dispatch attempt for audit trail (court evidence)
 */
async function logDispatch(envelope, agency, method, status) {
  try {
    const db = getDB();
    await db.collection('dispatch_log').insertOne({
      alertId:     envelope.alertId,
      agency,
      method,
      status,
      victimId:    envelope.victim.id,
      type:        envelope.type,
      dispatchedAt: new Date(),
    });
  } catch (err) {
    logger.error('[DISPATCH LOG ERROR]', err);
  }
}

/**
 * broadcastCriticalBattery()
 * Special broadcast when victim phone battery < 5%
 */
async function broadcastCriticalBattery(victimId, lat, lon, battery) {
  const db = getDB();
  const caseData = await db.collection('cases').findOne({ victimId });
  if (!caseData) return;

  const payload = {
    type:        'CRITICAL_BATTERY',
    priority:    'HIGH',
    victimId,
    victimName:  caseData.victimName,
    caseId:      caseData.caseId,
    lat, lon,
    message: `WARNING: ${caseData.victimName}'s device battery at ${battery}%. Device may go offline soon. Last GPS: ${lat}, ${lon}`,
    googleMapsUrl: `https://maps.google.com/?q=${lat},${lon}`,
    triggeredAt: new Date().toISOString(),
  };

  await Promise.allSettled([
    broadcastToAgencies({ ...payload, agency: 'NPF' }),
    broadcastToAgencies({ ...payload, agency: 'DSS' }),
  ]);
}

module.exports = {
  broadcastToAgencies,
  broadcastCriticalBattery,
  notifyFamily,
};
