/**
 * TRACER-NG — Database Configuration
 * MongoDB with connection pooling
 */

const { MongoClient } = require('mongodb');
const { logger } = require('../utils/logger');

let client;
let db;

async function connectDB() {
  const uri = process.env.MONGODB_URI || 'mongodb://localhost:27017';
  client = new MongoClient(uri, {
    maxPoolSize: 20,
    serverSelectionTimeoutMS: 5000,
    socketTimeoutMS: 45000,
  });

  await client.connect();
  db = client.db(process.env.DB_NAME || 'tracerng');

  // Create indexes for fast queries
  await db.collection('beacons').createIndex({ victimId: 1, receivedAt: -1 });
  await db.collection('beacons').createIndex({ receivedAt: 1 }, { expireAfterSeconds: 60 * 60 * 24 * 365 }); // 1 year TTL
  await db.collection('cases').createIndex({ victimId: 1 }, { unique: true });
  await db.collection('sos_events').createIndex({ status: 1, triggeredAt: -1 });

  logger.info(`[DB] Connected to MongoDB: ${db.databaseName}`);
  return db;
}

function getDB() {
  if (!db) throw new Error('Database not initialized. Call connectDB() first.');
  return db;
}

async function closeDB() {
  if (client) await client.close();
}

module.exports = { connectDB, getDB, closeDB };
