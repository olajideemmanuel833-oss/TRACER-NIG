/**
 * TRACER-NG Backend Server
 * Victim Location Intelligence System
 * Built for Nigeria 3MTT Cybersecurity Program
 */

const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const morgan = require('morgan');
const https = require('https');
const fs = require('fs');
require('dotenv').config();

const beaconRoutes = require('./routes/beacon');
const sosRoutes = require('./routes/sos');
const caseRoutes = require('./routes/cases');
const agencyRoutes = require('./routes/agencies');
const authRoutes = require('./routes/auth');

const { connectDB } = require('./config/database');
const { logger } = require('./utils/logger');

const app = express();
const PORT = process.env.PORT || 3000;

// ─── SECURITY MIDDLEWARE ────────────────────────────────────────────────────
app.use(helmet({
  contentSecurityPolicy: true,
  hsts: { maxAge: 31536000, includeSubDomains: true },
}));

// CORS — only allow registered agency IPs + mobile apps
app.use(cors({
  origin: (origin, callback) => {
    const allowed = [
      process.env.DASHBOARD_URL,      // Law enforcement dashboard
      process.env.MOBILE_APP_ORIGIN,  // React Native app
      'http://localhost:3001',         // Dev dashboard
    ].filter(Boolean);
    if (!origin || allowed.includes(origin)) return callback(null, true);
    callback(new Error('CORS: Origin not authorized'));
  },
  credentials: true,
}));

// ─── RATE LIMITING ──────────────────────────────────────────────────────────
// Beacon endpoint: allow frequent pings from mobile
const beaconLimiter = rateLimit({
  windowMs: 60 * 1000,   // 1 minute
  max: 10,               // max 10 beacons per minute per device
  keyGenerator: (req) => req.headers['x-device-imei'] || req.ip,
  message: { error: 'Beacon rate limit exceeded' },
});

// SOS endpoint: very permissive — never block an emergency
const sosLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 30,               // 30 SOS attempts per minute (generous)
  keyGenerator: (req) => req.headers['x-device-imei'] || req.ip,
});

// API general limiter
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,  // 15 minutes
  max: 500,
  message: { error: 'Too many requests, please try again later' },
});

// ─── GENERAL MIDDLEWARE ─────────────────────────────────────────────────────
app.use(express.json({ limit: '50kb' }));
app.use(express.urlencoded({ extended: true }));
app.use(morgan('combined', { stream: { write: (msg) => logger.info(msg.trim()) } }));
app.use(apiLimiter);

// ─── HEALTH CHECK ───────────────────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({
    status: 'operational',
    system: 'TRACER-NG',
    version: '1.0.0',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
  });
});

// ─── ROUTES ─────────────────────────────────────────────────────────────────
app.use('/api/auth',     authRoutes);
app.use('/api/beacon',   beaconLimiter, beaconRoutes);   // GPS beacon intake
app.use('/api/sos',      sosLimiter, sosRoutes);          // Emergency SOS
app.use('/api/cases',    caseRoutes);                     // Case management
app.use('/api/agencies', agencyRoutes);                   // Agency dispatch

// ─── 404 HANDLER ────────────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint not found' });
});

// ─── GLOBAL ERROR HANDLER ───────────────────────────────────────────────────
app.use((err, req, res, next) => {
  logger.error(`[ERROR] ${err.message}`, { stack: err.stack });
  res.status(err.status || 500).json({
    error: process.env.NODE_ENV === 'production'
      ? 'Internal server error'
      : err.message,
  });
});

// ─── START SERVER ────────────────────────────────────────────────────────────
async function start() {
  await connectDB();

  // Use HTTPS in production (required for GPS data security)
  if (process.env.NODE_ENV === 'production' && fs.existsSync('./ssl/cert.pem')) {
    const sslOptions = {
      key:  fs.readFileSync('./ssl/key.pem'),
      cert: fs.readFileSync('./ssl/cert.pem'),
    };
    https.createServer(sslOptions, app).listen(443, () => {
      logger.info('TRACER-NG server running on HTTPS :443');
    });
  } else {
    app.listen(PORT, () => {
      logger.info(`TRACER-NG server running on http://localhost:${PORT}`);
      logger.info('Environment: ' + (process.env.NODE_ENV || 'development'));
    });
  }
}

start().catch((err) => {
  logger.error('Failed to start server:', err);
  process.exit(1);
});

module.exports = app;
