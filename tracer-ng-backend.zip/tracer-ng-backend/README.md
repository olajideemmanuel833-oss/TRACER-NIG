# 🛰️ TRACER-NG Backend Server
### Victim Location Intelligence System
**Nigeria 3MTT Cybersecurity Project**

---

## 📁 Project Structure

```
tracer-ng-backend/
├── server.js                   # Main Express server
├── package.json
├── .env.example                # Copy to .env and fill in values
│
├── routes/
│   ├── beacon.js               # GPS beacon intake (/api/beacon)
│   ├── sos.js                  # Emergency SOS (/api/sos)
│   ├── cases.js                # Case management (/api/cases)
│   ├── agencies.js             # Agency management (/api/agencies)
│   └── auth.js                 # Authentication (/api/auth)
│
├── services/
│   ├── agencyDispatch.js       # NPF / DSS / DHQ alert dispatch
│   └── smsService.js           # Africa's Talking + Termii SMS
│
├── config/
│   └── database.js             # MongoDB connection
│
├── middleware/
│   └── auth.js                 # JWT authentication
│
└── utils/
    ├── crypto.js               # AES-256 encryption/decryption
    └── logger.js               # Winston structured logging
```

---

## 🚀 Quick Start

### 1. Install Node.js (v18+)
```bash
# Download from: https://nodejs.org
node --version   # Should show v18.x.x or higher
```

### 2. Install MongoDB
```bash
# Ubuntu/Debian (most Nigerian VPS servers)
sudo apt update
sudo apt install -y mongodb
sudo systemctl start mongodb
sudo systemctl enable mongodb
```

### 3. Clone & Install
```bash
git clone https://github.com/your-username/tracer-ng-backend.git
cd tracer-ng-backend
npm install
```

### 4. Configure Environment
```bash
cp .env.example .env
nano .env   # Fill in your keys and phone numbers
```

### 5. Generate Security Keys
```bash
# Generate JWT secret
npm run generate-key

# Generate AES-256 encryption key (64 hex chars)
npm run generate-key
```

### 6. Start the Server
```bash
# Development (auto-restart on changes)
npm run dev

# Production
npm start
```

---

## 🌐 API Endpoints

### GPS Beacon
```
POST   /api/beacon                    Receive GPS beacon from mobile app
POST   /api/beacon/cache-sync         Sync offline cached locations
GET    /api/beacon/:victimId/history  Get full location history
GET    /api/beacon/:victimId/last-known  Get last location (works if phone is off)
```

### SOS Emergency
```
POST   /api/sos                       Trigger emergency SOS
POST   /api/sos/:sosId/resolve        Mark SOS as resolved
GET    /api/sos/active                Get all active SOS alerts
```

### Cases
```
POST   /api/cases                     Register new kidnapping case
GET    /api/cases                     List all active cases
GET    /api/cases/:caseId             Get single case details
PATCH  /api/cases/:caseId/status      Update case status
```

---

## 📡 How Beacon Tracking Works

```
Mobile App (Victim's Phone)
        │
        │  POST /api/beacon
        │  Headers: Authorization: Bearer <device_token>
        │           X-Device-IMEI: 35XXXXXXXXX
        │  Body: { lat, lon, accuracy, battery, type, ... }
        │
        ▼
  TRACER-NG Server
        │
        ├── Decrypts AES-256 payload
        ├── Validates Nigeria coordinates
        ├── Stores beacon in MongoDB
        ├── Updates case "last known location"
        ├── Checks battery level
        │     └── If < 5%: alerts agencies
        └── If type=FINAL_BEACON: marks device offline
```

---

## 🚨 SOS Flow

```
Victim Triggers SOS (shake / 5-tap / gesture)
        │
  POST /api/sos ──→ Server immediately responds "received"
        │
        └── Async processing:
              ├── Records SOS event in DB
              ├── Updates case to SOS_ACTIVE
              ├── Sends webhook to NPF  ─┐
              ├── Sends webhook to DSS   ├── Parallel
              ├── Sends webhook to DHQ  ─┘
              ├── SMS fallback if any webhook fails
              └── Notifies family contact via SMS
```

---

## 🔐 Security Features

| Feature | Implementation |
|---|---|
| Data Encryption | AES-256-GCM for all GPS payloads |
| Authentication | JWT tokens per device |
| Rate Limiting | 10 beacons/min, 30 SOS/min |
| HTTPS | Required in production |
| CORS | Whitelist only |
| Audit Trail | Every dispatch logged for court evidence |

---

## 📱 Supported Phone Networks (SMS)

- ✅ MTN Nigeria
- ✅ Airtel Nigeria
- ✅ Glo Nigeria
- ✅ 9mobile (Etisalat)

---

## 🛠️ Deployment (Ubuntu VPS)

```bash
# Install PM2 for production process management
npm install -g pm2

# Start with PM2
pm2 start server.js --name tracer-ng

# Auto-restart on server reboot
pm2 startup
pm2 save

# Monitor
pm2 status
pm2 logs tracer-ng
```

---

## 📞 SMS Provider Setup

### Africa's Talking (Recommended)
1. Register at: https://africastalking.com
2. Create a production app
3. Get API Key from dashboard
4. Add to .env: AFRICASTALKING_API_KEY and AFRICASTALKING_USERNAME

### Termii (Backup)
1. Register at: https://termii.com
2. Get API key
3. Add to .env: TERMII_API_KEY

---

*Built for Nigeria's 3 Million Tech Talent Program*
*Cybersecurity Track — Public Safety Innovation*
